class Client < ApplicationRecord
  validates_presence_of :client_name
end
